import processing.core.PApplet;
import processing.serial.Serial;

public class Main extends PApplet {

	private static final long serialVersionUID = 1L;
	private Serial port;
	private String message = "";

	public void setup() {
		smooth(2);
		size(500, 500);
		// System.out.println("Taco");
		for (int i = 0; i < Serial.list().length; i++) {
			System.out.println(Serial.list()[i]);
		}

		port = new Serial(this, Serial.list()[0], 9600);
		println("Inicializa en: " + Serial.list()[0]);
	}

	public void draw() {
		background(255);
		fill(255);
		rect(0, 0, 250, 500);
		fill(0);
		rect(250, 0, 250, 500);

		if (frameCount % 60 == 0) {
			port.write(""+mouseX+"");
			println("env�o: "+ mouseX);
		}
	}
}
