package main;

import java.util.LinkedList;
import processing.core.*;
import processing.serial.Serial;

public class Main extends PApplet {

	private LinkedList<Persona> personas;
	private Mirror mir;
	private Serial port;
	private boolean serial;
	private int contador;

	public void settings() {
		size(800, 900);
	}

	public void setup() {
		serial = true;
		personas = new LinkedList<Persona>();
		mir = new Mirror(this);
		mir.setPos(300, 500);
		if (serial) {
			for (int i = 0; i < Serial.list().length; i++) {
				System.out.println(Serial.list()[i]);
			}
			int elegido = 0;
			port = new Serial(this, Serial.list()[elegido], 9600);
			println("Inicializa en: " + Serial.list()[elegido]);
		}
		personas.add(new Persona(this, new PVector(100, 100), new PVector(100, 100)));
		personas.add(new Persona(this, new PVector(500, 100), new PVector(100, 100)));
	}

	public void draw() {
		background(0);
		fill(255);
		// EJECUTA EL ESPEJO Y CALCULA EL ANGULO DE LA 1ERA Y ULTIMA PERSONA
		mir.calcular(personas, true);
		mir.showEspejo();
		int ang = (int) mir.getAnguloEspejo();
		if(ang > 180){
			ang -= 180;	
		}
		
		if (serial) {
			if (contador < millis()) {
				if (ang < 170 && ang > 10 ) {
					String angulito = String.valueOf(ang);
					port.write(angulito);
					System.out.println("Envía: " + angulito);
				}
				contador = millis() + 1000;
			}
		}

		for (int i = 0; i < personas.size(); i++) {
			personas.get(i).draw(i);
		}

		textSize(100);
		fill(255);
		text(ang, width/2f, height*0.75f);
		textSize(10);
	}

	public static void main(String[] args) {
		PApplet.main("main.Main");
	}

	public void mousePressed() {
		if (dist(mir.getPos().x, mir.getPos().y, mouseX, mouseY) < 50) {
			mir.setAgarrando(true);
		}
	}

	public void mouseReleased() {
		mir.setAgarrando(false);
	}
}
