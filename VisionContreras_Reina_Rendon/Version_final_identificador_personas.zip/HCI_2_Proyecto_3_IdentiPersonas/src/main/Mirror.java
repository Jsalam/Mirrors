package main;

import java.util.LinkedList;
import processing.core.PApplet;
import processing.core.PConstants;
import processing.core.PVector;

public class Mirror {
	PApplet app;
	PVector pos;
	float movimiento = 1;
	boolean mover;
	float angle;
	float angleFirst;
	float angleLast;
	float averageAngle;
	float finalAngle;
	float anguloEspejo;
	boolean agarrando;
	
	public Mirror(PApplet app) {
		this.app = app;
		pos = new PVector();
	}

	public void calcular(LinkedList<Persona> visitors, boolean visitorInInteraction) {
		// If any visitor is beyond the x coordinate of the mirror
		if (visitorInInteraction) {
			// movimiento = 0;
			// calculate the angle to the first visitor
			angleFirst = calcAngle(visitors.get(0));
//			angleFirst = calcAngle(app.mouseX,app.mouseY);
			// calculate angle to the last visitor
			angleLast = calcAngle(visitors.get(1));
			// calculate average angle
			averageAngle = (angleFirst + angleLast) / 2;
//			finalAngle=(float) Math.toDegrees(averageAngle);
			// Here we make a transformation, but it should be done with
			// trigonometry operations
			
			// app.ellipse(pos.x, pos.y, 30, 30);
			
			calculoAngulo(averageAngle);
//			System.out.println("angulo gg: "+calculoAngulo(averageAngle));
//			System.out.println("angulo riko: "+Math.toDegrees(averageAngle));
//			 System.out.println("Angulo 1ero: " +  Math.toDegrees(angleFirst));
			// System.out.println("Angulo 2do: " + angleLast);
//			System.out.println("angle average between users: " + finalAngle);
			guideLine(visitors);
		}
	}
	
	public void showEspejo(){
		//Original
		app.pushMatrix();
		app.translate(pos.x, pos.y);
		app.rotate(averageAngle);
		app.noFill();
		app.stroke(255);
		app.line(0, 15, 0, -15);
		app.line(5, 0, 9, 0);
		app.popMatrix();
		app.noFill();
		

		//De muestra
		app.pushMatrix();
		app.strokeCap(PConstants.ROUND);
		app.translate(app.displayWidth/2f, app.displayHeight/2f);
		app.rotate(averageAngle);
		app.strokeWeight(4);
		
		//Espejo
		app.stroke(0, 0, 255);
		app.line(0, 50, 0, -50);
		
		//Ángulo
		app.stroke(255);
		app.line(-5, 0, -40, 0);
		
		//Espectro
		app.stroke(255, 255, 255, 100);
		app.line(0, 0, -80, 40);
		app.line(0, 0, -80, -40);
		app.popMatrix();
		

		app.noFill();
		if(agarrando){
			pos.x = app.mouseX;
			pos.y = app.mouseY;
		}
	}

	public void guideLine(LinkedList<Persona> visitors) {
		for (int i = 0; i < 2; i++) {
			Persona v = visitors.get(i);
			app.strokeWeight(2);
			app.stroke(255);
			app.line(v.pos.x, v.pos.y, pos.x, pos.y);
		}
		/*
		for (Persona v : visitors) {
			app.line(v.pos.x, v.pos.y, pos.x, pos.y);
		}*/
	}

	public PVector getPos() {
		return pos;
	}

	public void setPos(PVector pos) {
		this.pos = pos;
	}

	public void setPos(float x, float y) {
		pos.x = x;
		pos.y = y;
	}

	public float getAngle() {
		return angle;
	}

	public void setAngle(float angle) {
		this.angle = angle;
	}

	public float calcAngle(Persona visit) {
		return PApplet.atan2(pos.y - visit.pos.y, pos.x - visit.pos.x);
	}
	
	public float calculoAngulo(float averageAngle) {
		 float degreesAngle=(float) Math.toDegrees(averageAngle);
//		 anguloEspejo  = (Math.abs(180 - degreesAngle)) / 2;
		 anguloEspejo  = (Math.abs(180 - degreesAngle));
		return anguloEspejo;
	}
	
//	public float calcAngle(int x,int y) {
//		return PApplet.atan2(pos.y - y, pos.x - x);
//	}

	public float getFinalAngle() {
		return finalAngle;
	}

	public void setFinalAngle(float finalAngle) {
		this.finalAngle = finalAngle;
	}

	public float getAnguloEspejo() {
		return anguloEspejo;
	}
	
	public void setAgarrando(boolean agarrando) {
		this.agarrando = agarrando;
	}
}
