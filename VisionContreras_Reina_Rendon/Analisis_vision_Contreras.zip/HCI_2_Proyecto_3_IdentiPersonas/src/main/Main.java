package main;

import java.util.ArrayList;
import java.util.LinkedList;

import processing.core.*;
import processing.video.*;

public class Main extends PApplet {

	Capture cap;
	Motion mot;
	LinkedList<Persona> personas;
	Movie mov;
	boolean verificar;
	boolean camara;


	
	
	Mirror mir;

	public void settings() {
		fullScreen();
	}

	public void setup() {
		// _________________________________________
		// CONDICIÓN PARA ELEGIR QUÉ VISUALIZAR
		// _________________________________________
		// true = cámara, false = video
		camara = false;
		if (camara) {
			cap = new Capture(this, 640, 480);
			cap.start();
		} else {
			mov = new Movie(this, "prueba (3).mp4");
			mov.loop();
		}
		mot = new Motion(this);
		personas = new LinkedList<Persona>();

		mir = new Mirror(this);
		
		
	}

	public void draw() {
		background(255);
		if (camara) {
			if (cap.available()) {
				cap.read();
			}
			if (!verificar) {
				mot.setup(cap.width, cap.height);
				verificar = true;
			}
		} else if (mov.available()) {
			mov.read();
			if (!verificar) {
				mot.setup(mov.width, mov.height);
				verificar = true;
			}
		}
		if (camara) {
			image(mot.update(cap), 0, 0);
			image(cap, cap.width, 0);
			analizar();
		} else if (mov.width > 0) {
			image(mot.update(mov), 0, 0);
			image(mov, mov.width, 0);
			analizar();
		}
		for (int i = 0; i < personas.size(); i++) {
			personas.get(i).draw(i);
			if (personas.get(i).getContador() + 1000 < millis()) {
				personas.remove(i);
			}
		}

		fill(255);
		text("Frame Rate: " + round(frameRate), 500, 50);

		// EJECUTA EL ESPEJO Y CALCULA EL ANGULO DE LA 1ERA Y ULTIMA PERSONA
		if (personas.size() >1) {
			mir.setPos(400, 800);
			mir.show(personas, true);
		}
		
		System.out.println("angulo para enviar: "+mir.getAnguloEspejo());
	
		
	
	}

	public void analizar() {
		ArrayList<Resultado> myRes = mot.getRes();
		// Dibuja un círculo individual para cada vector
		for (int i = 0; i < myRes.size(); i++) {
			Resultado rr = myRes.get(i);
			int cx = rr.x + rr.w / 2;
			int cy = rr.y + rr.h / 2;

			int contador = 0;
			for (int j = 0; j < personas.size(); j++) {
				if (personas.get(j).setPos(cx, cy, rr.w, rr.h)) {
					contador += 1;
					break;
				}
			}
			if (contador < 1) {
				personas.add(new Persona(this, new PVector(cx, cy), new PVector(rr.w, rr.h)));
				System.out.println("Agrega, actual: " + personas.size());
			}
		}
	}

	public void completo() {
		ArrayList<Resultado> myRes = mot.getRes();
		// To draw individual motion vector from the the list of results.
		for (int i = 0; i < myRes.size(); i++) {
			Resultado rr = myRes.get(i);
			int cx = rr.x + rr.w / 2;
			int cy = rr.y + rr.h / 2;
			int r1 = min(rr.w, rr.h) / 2;
			int r2 = min(10, r1 / 6);
			int x1 = (int) (cx + r1 * cos(radians(rr.angle)));
			int y1 = (int) (cy + r1 * sin(radians(rr.angle)));

			// Draw the arrows.
			line(x1, y1, cx, cy);
			line(x1, y1, x1 + r2 * cos(radians((float) (180.0 + rr.angle - 20))),
					y1 + r2 * sin(radians((float) (180.0 + rr.angle - 20))));
			line(x1, y1, x1 + r2 * cos(radians((float) (180.0 + rr.angle + 20))),
					y1 + r2 * sin(radians((float) (180.0 + rr.angle + 20))));
		}
		text("Frame Rate: " + round(frameRate), 500, 50);
	}


	public static void main(String[] args) {
		PApplet.main("main.Main");
	}
}
