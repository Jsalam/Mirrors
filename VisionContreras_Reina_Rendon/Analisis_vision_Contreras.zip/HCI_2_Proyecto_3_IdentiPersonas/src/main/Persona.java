package main;

import processing.core.*;

public class Persona {
	PApplet app;
	PVector pos, medidas;
	int contador;
	int identificador;

	public Persona(PApplet app, PVector pos, PVector medidas) {
		this.app = app;
		this.pos = pos;
		this.medidas = medidas;
		contador = app.millis();
	}
	
	public void draw(int identificador){
		this.identificador = identificador;
		app.stroke(255, 0, 0);
		if(identificador < 2){
			app.fill(255);
			app.ellipseMode(PConstants.CENTER);
			app.ellipse(pos.x, pos.y, 20, 20);
		}
		app.fill(255, 50);
		app.rectMode(PConstants.CENTER);
		app.rect(pos.x, pos.y, medidas.x, medidas.y);
		app.fill(0);
		app.textAlign(PConstants.CENTER, PConstants.CENTER);
		app.text(identificador, pos.x, pos.y);
	}
	
	public boolean setPos(float x, float y, float ancho, float alto){
		boolean evalua = false;
		if(PApplet.dist(pos.x, pos.y, x, y)<medidas.x*0.5f){
			pos.x = x;
			pos.y = y;
			medidas.x = ancho;
			medidas.y = alto;
			contador = app.millis();
			evalua = true;
		}
		return evalua;
	}
	
	public int getContador() {
		return contador;
	}
	
}
