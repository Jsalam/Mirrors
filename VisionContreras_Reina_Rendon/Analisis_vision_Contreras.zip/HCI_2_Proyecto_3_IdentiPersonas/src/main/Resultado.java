package main;
public class Resultado {
  // A temporary class to hold the motion component result.
  int x;
  int y;
  int w;
  int h;
  float angle;
 
  Resultado(int _x, int _y, int _w, int _h, float _a) {
    x = _x;
    y = _y;
    w = _w;
    h = _h;
    angle = _a;
  }
}